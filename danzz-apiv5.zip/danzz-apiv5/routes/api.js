__path = process.cwd()

var fetch = require('node-fetch');
var cheerio = require('cheerio');
var request = require('request');
var express = require('express');
var router  = express.Router();

// Settings
// Apikey
listkey = ["danzz","danzzgz"];

// Author
author = "Danzz Inc."

// Mess err
mess = {
    error: {
        status: false,
        code: 503,
        message: 'Error, Service Unavaible',
        maintanied_by: 'Danzz Coding'
    },
    noturl: {
    	status: false,
    	code: 403,
    	message: 'Error, Invlid Url',
    	maintanied_by: 'Danzz Coding'
    },
    nottext: {
    	status: false,
    	code: 403,
    	message: 'Error, Invlid Text',
    	maintanied_by: 'Danzz Coding'
    },
    nottext1: {
    	status: false,
    	code: 403,
    	message: 'Error, Invlid Text 1',
    	maintanied_by: 'Danzz Coding'
    },
    nottext2: {
    	status: false,
    	code: 403,
    	message: 'Error, Invlid Text 2',
    	maintanied_by: 'Danzz Coding'
    },
    notnum: {
    	status: false,
    	message: 'Enter Num',
    	maintanied_by: 'Danzz Coding'
    },
    notpage: {
    	status: false,
    	message: 'Enter Page',
    	maintanied_by: 'Danzz Coding'
    },
    notmoji1: {
    	status: false,
    	code: 403,
    	message: 'Error, Invlid Emoji 1',
    	maintanied_by: 'Danzz Coding'
    },
    notmoji2: {
    	status: false,
    	code: 403,
    	message: 'Error, Invlid Emoji 2',
    	maintanied_by: 'Danzz Coding'
    },
    notquery: {
    	status: false,
    	code: 403,
    	message: 'Error, Invlid Query',
    	maintanied_by: 'Danzz Coding'
    },
    notapikey: {
    	status: false,
    	code: 403,
    	message: 'Error, Invalid Apikey, Please Check The Apikey In Dash',
    	maintanied_by: 'Danzz Coding'
    },
    notapikeyprem: {
    	status: false,
    	code: 403,
    	message: 'Error, Invalid Apikey, You Are Not A Premium User, Buy In Pricing',
    	maintanied_by: 'Danzz Coding'
    },
    notapikeyvip: {
    	status: false,
    	code: 403,
    	message: 'Error, Invalid Apikey, You Are Not A VIP User, Buy In Pricing',
    	maintanied_by: 'Danzz Coding'
    },
    notfound: {
    	status: false,
    	code: 404,
    	message: 'Error, Not Found',
    	maintanied_by: 'Danzz Coding'
    },
    notid: {
    	status: false,
    	code: 404,
    	message: 'Error, Invalid Id or Username',
    	maintanied_by: 'Danzz Coding'
    },
    ready: {
    	status: false,
    	code: 403,
    	message: 'Error, ​​Already In Use',
    	maintanied_by: 'Danzz Coding'
    }
}

// Variable
/*!
* var apikey = req.query.apikey
* var query = req.query.q
* var text = req.query.text
* var url = req.query.url
*/


// Features
// Downloader
router.get('/downloader/facebook', async (req, res, next) => {
	var apikey = req.query.apikey
	var url = req.query.url
	if (!url) return res.json(mess.noturl)
	if (!apikey) return res.json(mess.notapikey)
	if(listkey.includes(apikey)){
	
	let data = await fetchJson(`https://danzzapi.xyz/api/downloader/facebook?url=${url}&apikey=danzz`)
	res.json({
	status: true,
	author: `${author}`,
	result: data.result
	})
} else {
  res.json(mess.notapikey)
}
})

router.get('/downloader/ttmp3', async (req, res, next) => {
	var apikey = req.query.apikey
	var url = req.query.url
	if (!url) return res.json(mess.noturl)
	if (!apikey) return res.json(mess.notapikey)
	if(listkey.includes(apikey)){
	
	let data = await fetchJson(`https://danzzapi.xyz/api/downloader/ttmp3?url=${url}&apikey=danzz`)
	res.json({
	status: true,
	author: `${author}`,
	result: data.result
	})
} else {
  res.json(mess.notapikey)
}
})

router.get('/downloader/ttmp4', async (req, res, next) => {
	var apikey = req.query.apikey
	var url = req.query.url
	if (!url) return res.json(mess.noturl)
	if (!apikey) return res.json(mess.notapikey)
	if(listkey.includes(apikey)){
	
	let data = await fetchJson(`https://danzzapi.xyz/api/downloader/ttmp4?url=${url}&apikey=danzz`)
	res.json({
	status: true,
	author: `${author}`,
	result: data.result
	})
} else {
  res.json(mess.notapikey)
}
})

router.get('/downloader/soundcloud', async (req, res, next) => {
	var apikey = req.query.apikey
	var url = req.query.url
	if (!url) return res.json(mess.noturl)
	if (!apikey) return res.json(mess.notapikey)
	if(listkey.includes(apikey)){
	
	let data = await fetchJson(`https://danzzapi.xyz/api/downloader/soundcloud?url=${url}&apikey=danzz`)
	res.json({
	status: true,
	author: `${author}`,
	result: data.result
	})
} else {
  res.json(mess.notapikey)
}
})

// Asupan
router.get('/asupan/santuy', async (req, res, next) => {
var apikey = req.query.apikey
if(!apikey) return res.json(mess.notapikey)
if(listkey.includes(apikey)){
	
var requestSettings = {
url: `https://danzzapi.xyz/api/asupan/santuy?apikey=danzz`, method: 'GET', encoding: null };
request(requestSettings, function(error, response, body) {
res.set('Content-Type', 'video/mp4');
res.send(body)
})
} else {
  res.json(mess.notapikey)
}
})

module.exports = router
